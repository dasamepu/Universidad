/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.actividad2;

import javax.swing.JOptionPane;



/**
 *
 * @author HP-21B0003la
 */
public class Actividad2 {

    public static void main(String[] args) {
     int numero;
     
        numero= Integer.parseInt(JOptionPane.showInputDialog("Digite un número: "));
     
   if(numero ==15){
       JOptionPane.showMessageDialog(null, "***************");
   
   }
    if(numero ==10){
       JOptionPane.showMessageDialog(null, "**********");
   
   }
     if(numero ==9){
       JOptionPane.showMessageDialog(null, "*********");
   
   }
      if(numero ==8){
       JOptionPane.showMessageDialog(null, "********");
   
   }
       if(numero ==7){
       JOptionPane.showMessageDialog(null, "*******");
   
   }
        if(numero ==6){
       JOptionPane.showMessageDialog(null, "******");
   
   }
         if(numero ==5){
       JOptionPane.showMessageDialog(null, "*****");
   
   }
          if(numero ==4){
       JOptionPane.showMessageDialog(null, "****");
   
   }
           if(numero ==3){
       JOptionPane.showMessageDialog(null, "***");
   
   }
            if(numero ==2){
       JOptionPane.showMessageDialog(null, "**");
   
   }
             if(numero ==1){
       JOptionPane.showMessageDialog(null, "*");
   
   }
   else{
       JOptionPane.showMessageDialog(null, "No cumple las condiciones");
       
   }
                

    
    }
}
