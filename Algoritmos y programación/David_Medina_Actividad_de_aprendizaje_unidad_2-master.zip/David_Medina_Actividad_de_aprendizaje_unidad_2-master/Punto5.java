public class Ejercicio_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         int numero;
     
        numero= Integer.parseInt(JOptionPane.showInputDialog("Digite un número: "));
     
   if(numero ==15){
       JOptionPane.showMessageDialog(null, "***************");
   
   }
    if(numero ==10){
       JOptionPane.showMessageDialog(null, "**********");
   
   }
     if(numero ==9){
       JOptionPane.showMessageDialog(null, "*********");
   
   }
      if(numero ==8){
       JOptionPane.showMessageDialog(null, "********");
   
   }
       if(numero ==7){
       JOptionPane.showMessageDialog(null, "*******");
   
   }
        if(numero ==6){
       JOptionPane.showMessageDialog(null, "******");
   
   }
         if(numero ==5){
       JOptionPane.showMessageDialog(null, "*****");
   
   }
          if(numero ==4){
       JOptionPane.showMessageDialog(null, "****");
   
   }
           if(numero ==3){
       JOptionPane.showMessageDialog(null, "***");
   
   }
            if(numero ==2){
       JOptionPane.showMessageDialog(null, "**");
   
   }
             if(numero ==1){
       JOptionPane.showMessageDialog(null, "*");
   
   }
   else{
       JOptionPane.showMessageDialog(null, "No cumple las condiciones");
       
   }
           
    }
    
}
