# David_Medina_Actividad_de_aprendizaje_unidad_2

TALLER INTRODUCCION A LA PROGRAMACION (20%)
PROGRAMA DE INGENIERIA DE SISTEMA
MODALIDAD A DISTANCIA
1. Convertir cuantas horas, minutos y segundos hay en N minutos digitados
Ejemplo:
140 minutos son 2 Horas,20 minutos, 0 segundos
2. Realizar un programa que Ingrese los datos del deportista e imprima, si es acto o no 
para poder ejercer el deporte, con las siguientes condiciones.
a. Que sea mayor de 15 años
b. Que sea Colombiano
c. Que tengo un peso entre 60 y 90 kilos
3. Realice un programa que ingrese un Número de 3 dígitos. Lo divide en 3 dígitos
independiente, e imprimir cual no es ni mayor ni menor de los dígitos.
N=371; el Numero del medio es 3.
4. Realice un Programa en Java, Digitado 5 Ventas en el Almacén XYZ Calcular:
 Cuantas ventas Fueron Mayores 1.000.000?
 El Promedio de las Ventas?
 Cual Fue la Mayor Venta?
 Cual Fue la Menor Venta?
5. Imprimir el numero digitado del Rango 1 a 10 y el 15, solo acepta positivos,
Si el número digitado imprime un número de asteriscos:
Ejemplo si el numero digitado es 7, imprime ******* (7 asteriscos)
6. Digitado dos Dados, dado1 y dado2, utilizando la función Random (Aleatorio), si las 
cara de los dados cae dado1=6 y dado=4, imprimir eres un afortunado, sino cumple 
con la condición inténtalo de nuevo!!.
Funcion Random en Java:
 int dado1 = (int) (Math.random() * 6 + 1);
 int dado2 = (int) (Math.random() * 6 + 1);
7. Una empresa Mypime, paga a sus vendedores mediantes, comisiones, los 
vendedores reciben $250.000 pesos por semana, más el 9% de sus ventas durante esa 
semana, calcule cuanto es valor a pagar por mes vendedor, el número de vendedores 
son 5.

![image](https://user-images.githubusercontent.com/87206494/175835157-88203a10-711f-4054-8678-3866165e528c.png)
